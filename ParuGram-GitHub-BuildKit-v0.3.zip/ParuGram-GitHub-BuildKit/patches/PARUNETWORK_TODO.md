# Paru Network / AWG integration target

## Goal
ParuGram must remain usable on both Wi‑Fi and cellular networks. Network transitions (Wi‑Fi ↔ LTE/5G), temporary loss of validation, captive/changed routes, and interface changes must not leave Telegram stuck in a permanent disconnected state.

## Required behavior
1. Use Android `ConnectivityManager.NetworkCallback` to observe available/lost/changed networks.
2. Treat Wi‑Fi and cellular as supported transports; never hard-code Wi‑Fi-only behavior.
3. When the active network changes, re-check reachability and restart/rebind the Telegram transport when needed.
4. If the AWG tunnel is enabled, protect its underlying socket from the VPN tunnel and rebind it to the currently usable network to avoid VPN recursion.
5. Use exponential backoff for reconnect attempts with a bounded maximum and reset the backoff after a successful connection.
6. Avoid reconnect storms: serialize tunnel restarts and coalesce rapid network callbacks.
7. If a network disappears, fail over to the next validated network automatically.
8. If no validated network exists, wait and retry when Android reports a usable network instead of spinning.
9. Preserve Telegram's normal connection logic when Paru Network is disabled.
10. Never claim 100% uptime: Android, carrier, router, server, DNS, and Telegram-side outages can still make connectivity impossible.

## AWG layer
- Add Android `VpnService` under `TMessagesProj`.
- Add the AmneziaWG userspace backend/library.
- Parse the full AWG configuration, including Jc/Jmin/Jmax, S1-S4, H1-H4 and I1-I5 when present.
- Preserve Address, DNS, MTU, AllowedIPs, Endpoint and PersistentKeepalive.
- Add Paru Network settings UI with explicit status: Disabled / Connecting / Connected / Reconnecting / No network / Error.
- Request Android VPN permission only when the user enables the tunnel.
- Keep the existing exteraGram Python plugin engine intact.

## Icon
Use the exteraGram icon design as the base, with the red/reddish accent replaced by a purple accent. Do not redesign the shape.

## Security
Do not put a real private key in this repository. If an old WG/AWG configuration was exposed in chat, rotate that key before using the tunnel in a release build.
