#!/usr/bin/env bash
set -euo pipefail

if [ -d ParuGram/.git ]; then
  echo 'ParuGram source already exists.'
  exit 0
fi

git clone --depth 1 https://github.com/exteraSquad/exteraGram.git ParuGram
printf '\nParuGram source downloaded into ./ParuGram\n'
printf 'Next: configure API_KEYS and apply the source-level Paru Network/AWG integration.\n'
