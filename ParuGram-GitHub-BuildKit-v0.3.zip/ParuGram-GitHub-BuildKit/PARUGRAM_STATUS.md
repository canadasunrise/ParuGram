# ParuGram v0.3 status

This is a lightweight GitHub build kit, not a finished APK.

The eventual ParuGram fork must:
- build as an installable Android APK;
- retain Telegram client functionality;
- work on Wi-Fi and mobile data;
- handle Wi-Fi <-> mobile transitions and temporary network loss;
- reconnect cleanly after network changes;
- integrate AmneziaWG in-app rather than requiring a companion app;
- use the purple variant of the exteraGram launcher icon.

The large reference APK is intentionally excluded so the ZIP stays suitable for GitHub web upload.
Do not commit Telegram API credentials or WireGuard/AmneziaWG private keys.
