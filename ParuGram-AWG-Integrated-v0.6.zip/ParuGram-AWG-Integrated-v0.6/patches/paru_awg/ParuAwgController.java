package org.telegram.messenger.paru.awg;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.net.VpnService;

import androidx.annotation.Nullable;

import org.amnezia.awg.backend.GoBackend;
import org.amnezia.awg.backend.Tunnel;
import org.amnezia.awg.config.Config;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** In-process AWG controller for ParuGram. No companion application is required. */
public final class ParuAwgController {
    public enum State { DISABLED, CONNECTING, CONNECTED, RECONNECTING, NO_NETWORK, ERROR }

    private static final String TUNNEL_NAME = "paruawg";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "ParuAWG");
        t.setDaemon(true);
        return t;
    });

    private static volatile GoBackend backend;
    private static volatile Tunnel tunnel;
    private static volatile Config currentConfig;
    private static volatile String currentText;
    private static volatile Context appContext;
    private static volatile State state = State.DISABLED;
    private static volatile ConnectivityManager.NetworkCallback networkCallback;
    private static volatile Network lastValidatedNetwork;
    private static volatile boolean rebindQueued;

    private ParuAwgController() {}

    public static State getState() { return state; }
    public static boolean isConnected() { return state == State.CONNECTED; }

    private static synchronized GoBackend backend(Context context) throws Exception {
        if (backend == null) backend = new GoBackend(context.getApplicationContext());
        return backend;
    }

    private static Network validatedNetwork(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return null;
        if (Build.VERSION.SDK_INT >= 23) {
            Network active = cm.getActiveNetwork();
            if (active != null && isValidated(cm, active)) return active;
        }
        if (Build.VERSION.SDK_INT >= 21) {
            for (Network n : cm.getAllNetworks()) if (isValidated(cm, n)) return n;
        }
        return null;
    }

    private static boolean isValidated(ConnectivityManager cm, Network n) {
        NetworkCapabilities caps = cm.getNetworkCapabilities(n);
        return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
    }

    private static boolean hasValidatedNetwork(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        Network n = cm.getActiveNetwork();
        if (n == null) return false;
        NetworkCapabilities caps = cm.getNetworkCapabilities(n);
        return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
    }

    /** Connects after VPN permission has already been granted. */
    public static void connect(Context context, String configText, @Nullable Listener listener) {
        final Context app = context.getApplicationContext();
        appContext = app;
        EXECUTOR.execute(() -> {
            try {
                if (!hasValidatedNetwork(app)) {
                    state = State.NO_NETWORK;
                    if (listener != null) listener.onState(state, "No validated network");
                    return;
                }
                state = State.CONNECTING;
                if (listener != null) listener.onState(state, "Starting AmneziaWG");

                Config cfg = Config.parse(new ByteArrayInputStream(
                        configText.getBytes(StandardCharsets.UTF_8)));
                GoBackend b = backend(app);
                Tunnel t = new Tunnel() {
                    @Override public String getName() { return TUNNEL_NAME; }
                    @Override public void onStateChange(State newState) {
                        // Backend callback; controller state is updated below.
                    }
                };

                b.setState(t, Tunnel.State.UP, cfg);
                tunnel = t;
                registerNetworkMonitor(app);
                currentConfig = cfg;
                currentText = configText;
                state = State.CONNECTED;
                if (listener != null) listener.onState(state, "AmneziaWG connected");
            } catch (Throwable e) {
                state = State.ERROR;
                if (listener != null) listener.onState(state, e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        });
    }

    public static void disconnect(@Nullable Listener listener) {
        EXECUTOR.execute(() -> {
            try {
                GoBackend b = backend;
                Tunnel t = tunnel;
                if (b != null && t != null) b.setState(t, Tunnel.State.DOWN, null);
                tunnel = null;
                currentConfig = null;
                currentText = null;
                lastValidatedNetwork = null;
                unregisterNetworkMonitor(appContext);
                state = State.DISABLED;
                if (listener != null) listener.onState(state, "AmneziaWG disconnected");
            } catch (Throwable e) {
                state = State.ERROR;
                if (listener != null) listener.onState(state, e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        });
    }

    /** Queue at most one tunnel rebuild for a burst of Android connectivity callbacks. */
    public static void rebind(Context context, @Nullable Listener listener) {
        final String cfg = currentText;
        if (cfg == null || cfg.trim().isEmpty()) return;
        final Context app = context.getApplicationContext();
        appContext = app;
        synchronized (ParuAwgController.class) {
            if (rebindQueued) return;
            rebindQueued = true;
        }
        EXECUTOR.execute(() -> {
            try {
                Network n = validatedNetwork(app);
                if (n == null) {
                    state = State.NO_NETWORK;
                    if (listener != null) listener.onState(state, "Waiting for a validated network");
                    return;
                }
                if (lastValidatedNetwork != null && n.equals(lastValidatedNetwork) && state == State.CONNECTED) return;
                state = State.RECONNECTING;
                if (listener != null) listener.onState(state, "Network changed; rebuilding tunnel");
                GoBackend b = backend(app);
                Tunnel old = tunnel;
                if (old != null) {
                    try { b.setState(old, Tunnel.State.DOWN, null); } catch (Throwable ignored) {}
                }
                Config parsed = Config.parse(new ByteArrayInputStream(cfg.getBytes(StandardCharsets.UTF_8)));
                Tunnel nt = newTunnel();
                b.setState(nt, Tunnel.State.UP, parsed);
                tunnel = nt;
                currentConfig = parsed;
                lastValidatedNetwork = n;
                state = State.CONNECTED;
                if (listener != null) listener.onState(state, "Tunnel rebound");
            } catch (Throwable e) {
                state = hasValidatedNetwork(app) ? State.ERROR : State.NO_NETWORK;
                if (listener != null) listener.onState(state, e.getClass().getSimpleName() + ": " + e.getMessage());
            } finally {
                synchronized (ParuAwgController.class) { rebindQueued = false; }
            }
        });
    }

    private static Config parse(String text) throws Exception {
        if (text == null || text.trim().isEmpty()) throw new IllegalArgumentException("AWG config is empty");
        return Config.parse(new ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8)));
    }

    private static Tunnel newTunnel() {
        return new Tunnel() {
            @Override public String getName() { return TUNNEL_NAME; }
            @Override public void onStateChange(State newState) {}
        };
    }

    private static void registerNetworkMonitor(Context context) {
        if (Build.VERSION.SDK_INT < 24 || networkCallback != null) return;
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return;
        ConnectivityManager.NetworkCallback cb = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) {
                if (isValidated(cm, network)) rebind(context, null);
            }
            @Override public void onLost(Network network) {
                if (network.equals(lastValidatedNetwork)) {
                    lastValidatedNetwork = null;
                    rebind(context, null);
                }
            }
            @Override public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) {
                boolean validated = caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
                if (validated && !network.equals(lastValidatedNetwork)) rebind(context, null);
            }
        };
        try { cm.registerDefaultNetworkCallback(cb); networkCallback = cb; }
        catch (Throwable ignored) { networkCallback = null; }
    }

    private static void unregisterNetworkMonitor(Context context) {
        if (Build.VERSION.SDK_INT < 24 || networkCallback == null || context == null) return;
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) cm.unregisterNetworkCallback(networkCallback);
        } catch (Throwable ignored) {}
        networkCallback = null;
    }

    public static boolean prepare(Context context) {
        return VpnService.prepare(context) != null;
    }

    public interface Listener { void onState(State state, String detail); }
}
