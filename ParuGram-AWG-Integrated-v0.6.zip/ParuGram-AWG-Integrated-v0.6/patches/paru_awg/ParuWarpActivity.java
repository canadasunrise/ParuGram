package org.telegram.messenger.paru.awg;

import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.widget.Toast;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Internal activity: register WARP directly with Cloudflare, then start the in-process AWG tunnel. */
public final class ParuWarpActivity extends Activity {
    private static final int VPN_REQUEST = 9301;
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private String pendingConfig;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        begin();
    }

    private void begin() {
        Toast.makeText(this, "ParuGram: получение WARP-конфига…", Toast.LENGTH_SHORT).show();
        EXECUTOR.execute(() -> {
            try {
                CloudflareWarpRegistrar.Result r = CloudflareWarpRegistrar.register();
                runOnUiThread(() -> requestVpn(r.wireGuardConfig));
            } catch (Throwable e) {
                runOnUiThread(() -> {
                    Toast.makeText(this, "WARP: " + String.valueOf(e.getMessage()), Toast.LENGTH_LONG).show();
                    finish();
                });
            }
        });
    }

    private void requestVpn(String config) {
        pendingConfig = config;
        Intent intent = VpnService.prepare(this);
        if (intent != null) {
            startActivityForResult(intent, VPN_REQUEST);
        } else {
            startTunnel();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_REQUEST) {
            if (resultCode == RESULT_OK) startTunnel();
            else finish();
        }
    }

    private void startTunnel() {
        final String config = pendingConfig;
        pendingConfig = null;
        ParuAwgController.connect(this, config, (state, detail) -> runOnUiThread(() -> {
            if (state == ParuAwgController.State.CONNECTED) {
                Toast.makeText(this, "ParuGram: WARP подключён", Toast.LENGTH_SHORT).show();
                finish();
            } else if (state == ParuAwgController.State.ERROR || state == ParuAwgController.State.NO_NETWORK) {
                Toast.makeText(this, "WARP: " + detail, Toast.LENGTH_LONG).show();
                finish();
            }
        }));
    }
}
