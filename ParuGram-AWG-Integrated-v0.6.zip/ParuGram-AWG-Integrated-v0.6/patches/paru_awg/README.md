# ParuGram integrated AWG transport

Adds an in-app AmneziaWG transport using the embeddable Android backend. No companion application is required.

The normal flow is user-supplied AWG configuration. No private key or provider-specific configuration is embedded in the repository.
