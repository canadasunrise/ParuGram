package org.telegram.messenger.paru.awg;

import android.os.Build;

import org.amnezia.awg.crypto.KeyPair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;

/**
 * Registers a local WARP device directly with Cloudflare's consumer endpoint
 * and converts the returned device configuration into a WireGuard config.
 *
 * This deliberately does not use a third-party "WARP generator" website.
 * Cloudflare's public documentation documents the WARP client itself, not a
 * public generator API, so this class targets the endpoint used by the
 * consumer client and treats it as best-effort/replaceable integration.
 */
public final class CloudflareWarpRegistrar {
    private static final String REGISTER_URL = "https://api.cloudflareclient.com/v0a2158/reg";
    private static final String CLIENT_VERSION = "a-6.10-2158";
    private static final String USER_AGENT = "okhttp/3.12.1";
    private static final int TIMEOUT_MS = 15000;

    private CloudflareWarpRegistrar() {}

    public static Result register() throws Exception {
        final KeyPair pair = new KeyPair();
        final String installId = randomInstallId();
        final String fcmToken = installId + ":APA91b" + randomAlphaNumeric(134);
        final String tos = isoNow();

        JSONObject payload = new JSONObject()
                .put("key", pair.getPublicKey().toBase64())
                .put("install_id", installId)
                .put("fcm_token", fcmToken)
                .put("tos", tos)
                .put("model", androidModel())
                .put("serial_number", installId)
                .put("locale", Locale.getDefault().toLanguageTag());

        JSONObject response = postJson(REGISTER_URL, payload.toString());
        return parse(response, pair.getPrivateKey().toBase64());
    }

    private static Result parse(JSONObject response, String privateKey) throws Exception {
        JSONObject config = response.getJSONObject("config");
        JSONObject iface = config.getJSONObject("interface");
        JSONObject addresses = iface.getJSONObject("addresses");
        JSONArray peers = config.getJSONArray("peers");
        if (peers.length() == 0) throw new IllegalStateException("Cloudflare returned no WARP peer");

        JSONObject peer = peers.getJSONObject(0);
        String publicKey = peer.getString("public_key");
        JSONObject endpoint = peer.getJSONObject("endpoint");
        String endpointHost = endpoint.optString("host", "engage.cloudflareclient.com:2408");
        String addressV4 = addresses.optString("v4", "");
        String addressV6 = addresses.optString("v6", "");
        if (addressV4.isEmpty() && addressV6.isEmpty()) {
            throw new IllegalStateException("Cloudflare returned no tunnel address");
        }

        StringBuilder cfg = new StringBuilder(1024);
        cfg.append("[Interface]\n")
                .append("PrivateKey = ").append(privateKey).append('\n');
        if (!addressV4.isEmpty()) cfg.append("Address = ").append(addressV4).append("/32");
        if (!addressV6.isEmpty()) {
            if (cfg.charAt(cfg.length() - 1) != '\n') cfg.append(", ");
            cfg.append(addressV6).append("/128");
        }
        cfg.append('\n')
                .append("DNS = 1.1.1.1, 1.0.0.1, 2606:4700:4700::1111, 2606:4700:4700::1001\n")
                .append("MTU = 1280\n")
                .append("\n[Peer]\n")
                .append("PublicKey = ").append(publicKey).append('\n')
                .append("AllowedIPs = 0.0.0.0/0, ::/0\n")
                .append("Endpoint = ").append(endpointHost).append('\n')
                .append("PersistentKeepalive = 25\n");

        String deviceId = response.optString("id", "");
        String token = response.optString("token", "");
        return new Result(cfg.toString(), privateKey, deviceId, token);
    }

    private static JSONObject postJson(String urlText, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlText).openConnection();
        c.setConnectTimeout(TIMEOUT_MS);
        c.setReadTimeout(TIMEOUT_MS);
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setRequestProperty("User-Agent", USER_AGENT);
        c.setRequestProperty("CF-Client-Version", CLIENT_VERSION);
        c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        c.setRequestProperty("Accept", "application/json");
        try (OutputStream out = c.getOutputStream()) {
            out.write(body.getBytes(StandardCharsets.UTF_8));
        }

        int code = c.getResponseCode();
        InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String text = readAll(stream);
        if (code < 200 || code >= 300) {
            throw new IllegalStateException("Cloudflare registration HTTP " + code + ": " + text);
        }
        return new JSONObject(text);
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    private static String androidModel() {
        return Build.MANUFACTURER + " " + Build.MODEL;
    }

    private static String randomInstallId() {
        return randomAlphaNumeric(22);
    }

    private static String randomAlphaNumeric(int length) {
        final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        java.security.SecureRandom rng = new java.security.SecureRandom();
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) sb.append(chars.charAt(rng.nextInt(chars.length())));
        return sb.toString();
    }

    private static String isoNow() {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date());
    }

    public static final class Result {
        public final String wireGuardConfig;
        public final String privateKey;
        public final String deviceId;
        public final String token;

        Result(String wireGuardConfig, String privateKey, String deviceId, String token) {
            this.wireGuardConfig = wireGuardConfig;
            this.privateKey = privateKey;
            this.deviceId = deviceId;
            this.token = token;
        }
    }
}
