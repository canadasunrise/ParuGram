package org.telegram.messenger.paru.awg;

import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;

/** Internal permission/launch activity. It is part of ParuGram, not a companion app. */
public final class ParuAwgActivity extends Activity {
    private static final int VPN_REQUEST = 4401;
    private static final String EXTRA_CONFIG = "paru_awg_config";
    private static final String EXTRA_DISCONNECT = "paru_awg_disconnect";

    public static Intent disconnectIntent(Activity activity) {
        return new Intent(activity, ParuAwgActivity.class)
                .putExtra(EXTRA_DISCONNECT, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
    }

    public static Intent intent(Activity activity, String config) {
        return new Intent(activity, ParuAwgActivity.class)
                .putExtra(EXTRA_CONFIG, config)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (getIntent().getBooleanExtra(EXTRA_DISCONNECT, false)) {
            ParuAwgController.disconnect((s, detail) -> runOnUiThread(this::finish));
            return;
        }
        String config = getIntent().getStringExtra(EXTRA_CONFIG);
        if (config == null || config.trim().isEmpty()) { finish(); return; }
        Intent prepare = VpnService.prepare(this);
        if (prepare != null) {
            startActivityForResult(prepare, VPN_REQUEST);
        } else {
            startTunnel(config);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != VPN_REQUEST) return;
        if (resultCode == RESULT_OK) {
            String config = getIntent().getStringExtra(EXTRA_CONFIG);
            startTunnel(config);
        } else {
            finish();
        }
    }

    private void startTunnel(String config) {
        ParuAwgController.connect(getApplicationContext(), config, (s, detail) ->
                runOnUiThread(() -> {
                    if (s == ParuAwgController.State.CONNECTED || s == ParuAwgController.State.ERROR
                            || s == ParuAwgController.State.NO_NETWORK) finish();
                }));
    }
}
