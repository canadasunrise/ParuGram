from pathlib import Path
import re
root = Path('.')
mod = root / 'TMessagesProj'
java = mod / 'src/main/java/org/telegram/messenger/paru/awg'
java.mkdir(parents=True, exist_ok=True)
patch = root / 'patches' / 'paru_awg'
for name in ('ParuAwgController.java','ParuAwgActivity.java','CloudflareWarpRegistrar.java','ParuWarpActivity.java'):
    src = patch / name
    if src.exists():
        (java / name).write_text(src.read_text(encoding='utf-8'), encoding='utf-8')

gradle = mod / 'build.gradle'
s = gradle.read_text(encoding='utf-8')
dep = "implementation 'com.zaneschepke:amneziawg-android:2.3.7'"
if dep not in s:
    marker = 'dependencies {'
    if marker in s:
        s = s.replace(marker, marker + '\n    ' + dep, 1)
    else:
        s += '\n\ndependencies {\n    ' + dep + '\n}\n'
gradle.write_text(s, encoding='utf-8')

manifest = mod / 'src/main/AndroidManifest.xml'
s = manifest.read_text(encoding='utf-8')
service = '''\n        <service\n            android:name="org.amnezia.awg.backend.GoBackend$VpnService"\n            android:permission="android.permission.BIND_VPN_SERVICE"\n            android:exported="false">\n            <intent-filter>\n                <action android:name="android.net.VpnService" />\n            </intent-filter>\n        </service>\n'''
if 'org.amnezia.awg.backend.GoBackend$VpnService' not in s:
    pos = s.rfind('</application>')
    if pos < 0: raise SystemExit('AndroidManifest.xml: </application> not found')
    s = s[:pos] + service + s[pos:]
manifest.write_text(s, encoding='utf-8')

# Dedicated transport screen is exposed from SettingsActivity when that upstream class exists.
settings = None
for p in mod.glob('src/main/java/**/SettingsActivity.java'):
    if '/org/telegram/ui/' in str(p).replace('\\','/'):
        settings = p; break
if settings:
    s = settings.read_text(encoding='utf-8')
    if 'ParuAwgActivity' not in s:
        s = s.replace('package org.telegram.ui;', 'package org.telegram.ui;\n\nimport org.telegram.messenger.paru.awg.ParuAwgActivity;', 1)
        # Prefer a menu entry because it is independent of the many row-layout variants of SettingsActivity.
        marker = 'onCreateOptionsMenu'
        pos = s.find(marker)
        if pos >= 0:
            brace = s.find('{', pos)
            if brace >= 0:
                s = s[:brace+1] + '\n        try { getMenu().add("Paru Transport"); } catch (Throwable ignored) { }' + s[brace+1:]
        pos = s.find('onOptionsItemSelected')
        if pos >= 0:
            brace = s.find('{', pos)
            if brace >= 0:
                s = s[:brace+1] + '\n        if (item != null && "Paru Transport".contentEquals(item.getTitle())) { startActivity(ParuAwgActivity.intent(this, getSharedPreferences("paru_transport", MODE_PRIVATE).getString("config", ""))); return true; }' + s[brace+1:]
        settings.write_text(s, encoding='utf-8')
print('Paru AWG patch applied')
