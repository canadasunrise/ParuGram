# ParuGram GitHub BuildKit v0.3

Lightweight bootstrap kit for building the ParuGram fork on GitHub.

## Important
This archive does **not** contain a prebuilt APK and does **not** yet contain the complete modified exteraGram source tree. It is intentionally small enough for GitHub's web upload workflow.

A successful build of the eventual ParuGram source will produce an installable APK, but v0.3 itself must not be represented as a guaranteed finished client.

## Required final behavior
- Wi-Fi + mobile data support
- automatic recovery after network loss
- clean Wi-Fi/LTE/5G transitions
- in-app AmneziaWG integration
- purple exteraGram-style icon
- GitHub Actions APK artifact

Never commit Telegram API credentials or private VPN keys.

## v0.6 integrated transport

The GitHub build now applies the in-app AmneziaWG transport to the ParuGram source before compiling. No companion VPN application is required. Enter a user-provided AWG configuration in the transport screen and grant Android VPN permission when prompted.
