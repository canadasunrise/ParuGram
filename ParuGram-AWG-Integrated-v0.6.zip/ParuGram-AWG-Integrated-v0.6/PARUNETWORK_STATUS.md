# ParuGram integrated transport v0.6

The build workflow downloads the archived exteraGram source, applies the ParuGram branding, then adds an in-app AmneziaWG transport before compiling the APK.

Included:
- AmneziaWG Android backend dependency.
- Android VpnService declaration.
- In-process AWG controller.
- Network-change monitoring and serialized tunnel rebind.
- Dedicated transport entry point in SettingsActivity when the upstream source exposes that class.
- User-supplied configuration; no private key is embedded.

The transport does not guarantee availability when the configured endpoint itself is unreachable.
